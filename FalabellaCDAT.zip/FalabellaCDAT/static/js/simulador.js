// obtener elementos del formulario
const simuladorForm = document.getElementById('simuladorForm');
const seccionSimulador = document.getElementById('seccionSimulador');
const seccionResultados = document.getElementById('seccionResultados');

// obtener elementos de entrada
const tipoDocumentoInput = document.getElementById('tipoDocumento');
const documentoInput = document.getElementById('documento');
const abonoInput = document.getElementById('abono');
const vencimientoInput = document.getElementById('vencimiento');
const plazoInput = document.getElementById('plazo');
const toggleButtons = document.querySelectorAll('.toggle-btn');
const btnSimular = document.querySelector('.btn-simular');
const btnVolverSimular = document.getElementById('btnVolverSimular');

// obtener elementos de resultados
const montoTotalGrandeElement = document.getElementById('montoTotalGrande');
const plazoResultadoElement = document.getElementById('plazoResultado');
const rendimientosTotalElement = document.getElementById('rendimientosTotal');
const retencionElement = document.getElementById('retencion');
const valorInversionElement = document.getElementById('valorInversion');
const pagoRendimientosElement = document.getElementById('pagoRendimientos');
const tasaAnualElement = document.getElementById('tasaAnual');
const fechaInicialElement = document.getElementById('fechaInicial');
const fechaVencimientoElement = document.getElementById('fechaVencimiento');

// mapeo de dias a tasas de interes
const tasasPorDias = {
    30: 3.0,
    60: 4.0,
    90: 4.5,
    180: 5.0,
    360: 5.5,
    720: 6.0
};

// mapeo de valores a labels para vencimiento
const vencimientoLabels = {
    'vencimiento': 'Al vencimiento',
    'periodico': 'Abono periodico'
};

// funcion para formatear moneda
function formatearMoneda(valor) {
    return new Intl.NumberFormat('es-CO', {
        style: 'currency',
        currency: 'COP',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(valor);
}

// funcion para formatear fecha dd/mm/yyyy
function formatearFecha(fecha) {
    const d = new Date(fecha);
    const dia = String(d.getDate()).padStart(2, '0');
    const mes = String(d.getMonth() + 1).padStart(2, '0');
    const anio = d.getFullYear();
    return `${dia}/${mes}/${anio}`;
}

// funcion para calcular dias entre dos fechas
function calcularDias(fechaFin) {
    const hoy = new Date();
    hoy.setHours(0, 0, 0, 0);

    const fecha = new Date(fechaFin);
    fecha.setHours(0, 0, 0, 0);

    const diferencia = fecha - hoy;
    const dias = Math.ceil(diferencia / (1000 * 60 * 60 * 24));

    return dias;
}

// funcion para obtener tasa segun dias
function obtenerTasa(dias) {
    if (dias >= 720) return 6.0;
    if (dias >= 360) return 5.5;
    if (dias >= 180) return 5.0;
    if (dias >= 90) return 4.5;
    if (dias >= 60) return 4.0;
    if (dias >= 30) return 3.0;
    return 0;
}

// funcion para calcular tasa efectiva anual
function calcularTasaAnual(tasaNominal, dias) {
    // formula: ((1 + tasa/100)^(365/dias) - 1) * 100
    const tasaDecimal = tasaNominal / 100;
    const tasaAnual = (Math.pow(1 + tasaDecimal, 365 / dias) - 1) * 100;
    return tasaAnual;
}

// funcion para validar el formulario
function validarFormulario() {
    const tipoDocValido = tipoDocumentoInput.value !== '';
    const docValido = documentoInput.value.trim() !== '';
    const abonoValido = parseFloat(abonoInput.value) >= 200000;
    const vencimientoValido = vencimientoInput.value !== '';
    const plazoValido = plazoInput.value !== '';

    const formValido = tipoDocValido && docValido && abonoValido && vencimientoValido && plazoValido;

    // activar o desactivar boton segun validez
    if (formValido) {
        btnSimular.classList.add('active');
    } else {
        btnSimular.classList.remove('active');
    }
}

// agregar listeners a toggle buttons para vencimiento
toggleButtons.forEach(btn => {
    btn.addEventListener('click', function(event) {
        event.preventDefault();

        // remover clase active de todos los botones
        toggleButtons.forEach(b => b.classList.remove('active'));

        // agregar clase active al boton clickeado
        this.classList.add('active');

        // actualizar valor del input hidden
        vencimientoInput.value = this.dataset.value;

        // validar formulario
        validarFormulario();
    });
});

// agregar listeners a inputs para validar en tiempo real
tipoDocumentoInput.addEventListener('change', validarFormulario);
documentoInput.addEventListener('input', validarFormulario);
abonoInput.addEventListener('input', validarFormulario);
plazoInput.addEventListener('change', validarFormulario);

// agregar listener al formulario
simuladorForm.addEventListener('submit', function(event) {
    // prevenir envio del formulario
    event.preventDefault();

    // obtener valores del formulario
    const documento = documentoInput.value.trim();
    const abono = parseFloat(abonoInput.value);
    const vencimiento = vencimientoInput.value;
    const fechaPlazo = plazoInput.value;

    // validar que todos los campos esten completos
    if (!documento || !abono || !vencimiento || !fechaPlazo) {
        alert('Por favor completa todos los campos');
        return;
    }

    // validar que el abono sea mayor al minimo
    if (abono < 200000) {
        alert('El monto minimo es $200.000');
        return;
    }

    // calcular dias entre hoy y la fecha seleccionada
    const dias = calcularDias(fechaPlazo);

    // validar rango de dias
    if (dias < 30 || dias > 1080) {
        alert('El plazo debe estar entre 30 y 1080 dias');
        return;
    }

    // obtener la tasa de interes segun los dias
    const tasa = obtenerTasa(dias);

    // calcular intereses: abono * tasa / 100
    const intereses = abono * tasa / 100;

    // calcular retencion en la fuente (4% sobre los intereses)
    const retencion = intereses * 0.04;

    // calcular monto final: abono + intereses
    const montoFinal = abono + intereses;

    // calcular tasa efectiva anual
    const tasaAnual = calcularTasaAnual(tasa, dias);

    // obtener el label de vencimiento
    const vencimientoLabel = vencimientoLabels[vencimiento];

    // obtener fechas
    const hoy = new Date();
    const fechaVencimiento = new Date(fechaPlazo);
    const fechaInicialFormato = formatearFecha(hoy);
    const fechaVencimientoFormato = formatearFecha(fechaVencimiento);

    // actualizar elementos de resultados con valores formateados
    montoTotalGrandeElement.textContent = formatearMoneda(montoFinal);
    plazoResultadoElement.textContent = dias;
    rendimientosTotalElement.textContent = formatearMoneda(intereses);
    retencionElement.textContent = formatearMoneda(retencion);
    valorInversionElement.textContent = formatearMoneda(abono);
    pagoRendimientosElement.textContent = vencimientoLabel;
    tasaAnualElement.textContent = tasaAnual.toFixed(2) + '%';
    fechaInicialElement.textContent = fechaInicialFormato;
    fechaVencimientoElement.textContent = fechaVencimientoFormato;

    // ocultar seccion simulador y mostrar resultados
    seccionSimulador.style.display = 'none';
    seccionResultados.style.display = 'block';

    // hacer scroll a los resultados
    seccionResultados.scrollIntoView({ behavior: 'smooth' });
});

// agregar listener al boton volver a simular
btnVolverSimular.addEventListener('click', function() {
    // mostrar seccion simulador y ocultar resultados
    seccionSimulador.style.display = 'block';
    seccionResultados.style.display = 'none';

    // limpiar formulario
    simuladorForm.reset();

    // resetear toggle buttons
    toggleButtons.forEach(btn => btn.classList.remove('active'));
    toggleButtons[0].classList.add('active');
    vencimientoInput.value = 'vencimiento';

    // hacer scroll al formulario
    seccionSimulador.scrollIntoView({ behavior: 'smooth' });
});
